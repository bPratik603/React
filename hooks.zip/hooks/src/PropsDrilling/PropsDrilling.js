import React,{useState} from 'react'

export default function PropsDrilling() {

    const [fname,setFname] = useState("FirstName");
    const [lname,setLname] = useState("LastName");


  return (
      
      <>
          <hr></hr>
          <h1>Props Drilling</h1>
          <div>This is Parent component</div>
           <br></br>
         <ChildA fname={fname} lname={lname}/>
      </>
    
  )
}

function ChildA({fname,lname}){

    return(<>
      <div>This is a Child A Component</div>
      <br></br>
      <ChildB fname={fname} lname={lname}/>

    </>)
}

function ChildB({fname,lname}){

    return(<>
      <div>This is a Child B Component</div>
      <br></br>
      <ChildC fname={fname} lname={lname}/>
      
    </>)
}

function ChildC({fname,lname}){

    return(<>
      <div>This is a Child C Component</div>
       <h5>{fname}</h5>
       <h5>{lname}</h5>
      
    </>)
}

