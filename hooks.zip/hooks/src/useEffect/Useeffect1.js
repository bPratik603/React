import React,{useState,useEffect} from 'react'

export default function Useeffect1() {

    const [count,setCount] = useState(0);
    const [data,setData] = useState("hello");

    useEffect(()=>{
        console.log("useeffect called")
        document.title=`you clicked ${count} times`
    },[count])

    useEffect(()=>{
        console.log("useeffect called")
        document.title=`you clicked ${count} times`
    },[data])

    
  return (
    <div>
        <hr></hr>
        <h1>useEffect</h1>

        <h3>{data}</h3>

         <button onClick={()=>setData('seven mentor')}> Change data value</button>

        <button onClick={()=>setCount(count+1)}>cliked {count} times{"  "}</button>
    </div>
  )
}
