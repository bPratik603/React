import React,{useState,useContext} from 'react'
import { createContext } from 'react';

const UserContext = createContext();

export default function UseContext1() {

    const [user,setuser] = useState("Seven Mentor");


    
  return (
    <div>
        <hr></hr>
        <h1>useContext</h1>
            <UserContext.Provider value={user}>
                <h3>{`Hello my name is ${user}`}</h3>
               <Component1/>
            </UserContext.Provider>

            
    </div>
  )
}

function Component1(){
    return(
        <>
        <h3>This is a component 1</h3>
        <Component2/>
        </>
    )
}

function Component2(){
    return(
        <>
        <h3>This is a component 2</h3>
        <Component3/>
        </>
    )
}

function Component3(){
    return(
        <>
        <h3>This is a component 3</h3>
        <Component4/>
        </>
    )
}

function Component4(){

    const user = useContext(UserContext);

    return(
        <>
        <h3>This is a component 4</h3>
        <h3>{`Hello I'm back my name is ${user}`}</h3>
        </>
    )
}
