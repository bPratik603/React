import React,{useContext} from 'react'
import { AuthContext } from './AuthContext'

function Auth(){

    const auth = useContext(AuthContext);
    console.log(auth.status);

    return(
        <>
        <hr></hr>
        <h2>AuthContext</h2>
           <h3>Are you aunthicated?</h3>
           {
              auth.status?
              <p>Yes you are</p>
              :
              <p>Nopes</p>
           }

           <button onClick={auth.login}>Click to login</button>
        </>
    )
}

export default Auth;