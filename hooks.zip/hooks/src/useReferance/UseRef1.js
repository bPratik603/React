import React,{useRef} from 'react'

export default function UseRef1() {

    const focusPoint = useRef(null);

    const onClickHandler = ()=>{
          
        focusPoint.current.value = "We are learning useRef Hooks from react 18.0 version"
        focusPoint.current.focus();
        
        console.log(focusPoint)
    };

  return (
    <>
    <hr></hr>
    <h1>useRef</h1>
    <h3>useRef1</h3>
    <div>
         <button onClick={onClickHandler}>Action</button>  
    </div>
    <label>
        click on the button to focus
    </label><br></br>
    <textarea ref={focusPoint}></textarea>

    </>
  )
}
