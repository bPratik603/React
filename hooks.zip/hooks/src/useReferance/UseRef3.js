import React,{useState,useRef, useEffect} from 'react'

export default function UseRef3() {

    const [inputValue,setInputValue] = useState("");
    const previousInputValue = useRef("");

    useEffect(()=>{
        previousInputValue.current = inputValue
    },[inputValue]);

  return (
    <div>

        <h3>useRef3</h3>
          <input type='text' value={inputValue} onChange={(e)=>setInputValue(e.target.value)}/>

          <h5>current value: {inputValue}</h5>
          <h5>Previous value: {previousInputValue.current}</h5>  
          
    </div>
  )
}
