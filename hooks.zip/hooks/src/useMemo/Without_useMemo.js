import React,{useState} from 'react'

export default function Without_useMemo() {

    const [number,setNumber] = useState(0);
    const [count,setCount] = useState(0);

    const squaredNum = squareNum(number);

    function squareNum(number){
        console.log("square is done!");
        return Math.pow(number,2);
    }

   function onChangeHandler(e){
      setNumber(e.target.value);
   }
   
   function counterHandler(){
          
       setCount(count+1);
   }

  return (
    <div>
       <h3>Without useMemo</h3>
       <input type="text" value={number} onChange={onChangeHandler}/>
       <div>Output: {squaredNum}</div>
       <br></br>

       <button onClick={counterHandler}>count++</button>
       <div>Count: {count}</div>
    </div>
  )
}
