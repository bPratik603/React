import React,{useState,useMemo} from 'react'

export default function UseMemo1() {

  const [number,setNumber] = useState(0);
  const [count,setCount] = useState(0);

  const squaredNum = useMemo(()=>{
    return squareNum(number);
  },[number])

  function squareNum(number){
       console.log("square is done!");
       return Math.pow(number,2);
  }

  function onChangeHandler(e){
    setNumber(e.target.value);
  }

  function counterHandler(){
    setCount(count+1);
  }

  return (
    <div>
      <hr></hr>
      <h1>useMemo</h1>
        <div>see differance in console</div>
        <br></br>
      <input type="text" value={number} onChange={onChangeHandler}/>
      <div>Output: {squaredNum}</div>

     <button onClick={counterHandler}>count++</button> 

     <div>count: {count}</div>
    </div>
  )
}
