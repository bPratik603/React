import React,{useState,useMemo} from 'react'

export default function TodoList1() {
 
     const [count,setCount] = useState(0);
     const [todos,setTodos] = useState([]);

     const AddTodo = ()=>{
        setTodos((t)=>[...t,"new todo added"])
     }
  
     function Counter(){
        setCount(count+1);
     }

     const calculation = useMemo(()=>someCalculation(count),[count])

     function someCalculation(num){
        console.log("value is calculating...");
        for(let i=0;i<=1000000;i++){
            num+=1;
        }

        return num;
     }
  return (
    <div>
         <h2>Todo List</h2>

        {
            todos.map((todo,index)=>{
                return <p key={index}>{todo}</p>
            })
        }
        <button onClick={AddTodo}>Add todo</button>

        <br></br>
        <br></br>
        <div>count: {count}</div>
        <button onClick={Counter}>count++</button>

        <div>Some Calculation</div>
        <div>{calculation}</div>
    </div>
  )
}
