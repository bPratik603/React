import logo from './logo.svg';
import './App.css';

import UseState1 from './useState/UseState';
import Asach from './useState/asach';
import UserStateUsingArray from './useState/UserStateUsingArray';
import UseStateUsingObject from './useState/UseStateUsingObject';

import Useeffect1 from './useEffect/Useeffect1';

import UseRef1 from './useReferance/UseRef1';
import UseRef2 from './useReferance/UseRef2';
import UseRef3 from './useReferance/UseRef3';

import UseMemo1 from './useMemo/UseMemo1';
import Without_useMemo from './useMemo/Without_useMemo';

import TodoList1 from './useMemo/TodoList1';

import UseReducer1 from './useReducer/UseReducer1';

import PropsDrilling from './PropsDrilling/PropsDrilling';

import UseContext1 from './useContext/UseContext1';
import APPP from './useContext/APPP';

import UseCallback1 from './useCallback/UseCallback1';


function App() {
  return (
    <div className="App">
 
      <UseState1/>
      <Asach/>
      <UserStateUsingArray/>
      <UseStateUsingObject/>
      <Useeffect1/>
      <UseRef1/>

      {/* Comment Useeffect1 before call UseRef2 */}
      <UseRef2/>
      <UseRef3/>
      
      <UseMemo1/>
      <Without_useMemo/>
      <TodoList1/>

      <UseReducer1/>

      <PropsDrilling/>

      <UseContext1/>
      <APPP/>

      <UseCallback1/>
    </div>
  );
}

export default App;
