import React,{useReducer} from 'react'

const initialState = 0;

const reducer = (state,action)=>{
    switch(action){
        case "add":
            return state+=1;

        case "sub":
            return state-=1;
        
        case "reset":
            return 0;
        
        default:
            throw new Error ("unexceted action");
    }
}
export default function UseReducer1() {

    const [state,dispatch] = useReducer(reducer,initialState);
  return (
    <div>
      <hr></hr>
      <h1>useReducer</h1>

      <div>{state}</div>

      <button onClick={()=>dispatch("add")}>Add</button>
      <button onClick={()=>dispatch("sub")}>Sub</button>
      <button onClick={()=>dispatch("reset")}>Reset</button>
    </div>
  )
}
