import React,{useCallback, useState} from 'react'


const funcCount = new Set();

function UseCallback1(props) {

    const [count,setCount] = useState(0);
    const [number,setNumber] = useState(0);

    const incrementCounter = useCallback(()=>{
        setCount(count+1);
        console.log("counter++");
    },[count]);

    const decrementCounter = useCallback(()=>{
        setCount(count-1);
        console.log("counter--");
    },[count]);

    const incrementNumber = useCallback(()=>{
        setNumber(number+1);
        console.log("Number increment");
    },[number])

    funcCount.add(incrementCounter);
    funcCount.add(decrementCounter);
    funcCount.add(incrementNumber);

    
  return (
    <div>
        <hr></hr>
        <h1>useCallback</h1>
      <h3>Example of callback function</h3>
      <p>count: {count}</p>

      <p>count: {funcCount.size}</p>
      <button onClick={incrementCounter}>counter++</button>

      <button onClick={decrementCounter}>counter--</button>

      <button onClick={incrementNumber}>Incremented Number</button>


    </div>
  )
}



export default UseCallback1

