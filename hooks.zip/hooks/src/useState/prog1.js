import React,{useState} from 'react'

export default function prog1() {

     const [data,setData] = useState({username:"",password:""});

     const [form,setForm] = useState({username:"",password:""});

     const [submit,setSubmit] = useState(false);

     const printValues = (e)=>{
      e.preventDefault();
      setForm({username: data.username,password:data.password});
      setSubmit(true);
     };

     const updateField = (e)=>{
      setData({...data,[e.target.name]:e.target.value});
     };
  return (
    <div>
         <form onSubmit={printValues}>
          <label>
            username: <input type="text" value={data.username} name="username" onChange={updateField}/>
          </label>
<br></br>
          <label>
                password: <input type="password" value={data.password} name="password" onChange={updateField}/>
          </label>

          <br></br>

          <input type="submit" value="submit"/>
         </form>

         <p>
          {submit ? <h5>{form.username}</h5>:null}
          {submit ? <h5>{form.password}</h5>:null}
         </p>
    </div>
  )
}
