import React from 'react'

export default function Asach() {
  return (
    <div>
         <h1>By</h1>
    </div>
  )
}
