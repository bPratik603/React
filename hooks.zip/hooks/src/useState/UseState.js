import React,{useState} from 'react'

export default function UseState1() {
     
    const [click,setClick] = useState(0);

    return (
    <div>
           <h1>Hello</h1>
           <h1>Updated value : {click}</h1>
            <h3>You'r Clicked {click} times</h3>
            <h3>the number of times you have clicked is {click%2==0?'even':'odd'}</h3>
            
            
          
           <button onClick={()=>setClick(click+1)}>click me</button>


    </div>
  )
}
